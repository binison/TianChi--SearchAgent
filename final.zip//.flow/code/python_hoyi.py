from langstudio.core import tool
import requests
from typing import List, Dict
import time

@tool
def fetch_full_content(serp_output: List[Dict], max_pages: int = 3) -> str:
    """
    使用 Jina Reader 读取 SerpApi 结果中的网页正文。
    
    Args:
        serp_output: 上游 SerpApi 节点的输出列表。
        max_pages: 为了防止超时和 Token 溢出，限制读取前几页。
    """
    if not serp_output:
        return "No search results provided."

    results_text = []
    
    # 只取前 max_pages 个结果
    to_process = serp_output[:max_pages]

    for i, item in enumerate(to_process):
        url = item.get("link")
        title = item.get("title", "Untitled")
        
        # 1. 跳过 PDF (或者你想让 Jina 强行解析也可以去掉这行)
        if url.lower().endswith(".pdf"):
            results_text.append(f"### Source {i+1}: {title}\n[File is a PDF, skipped full text extraction. Summary: {item.get('summary')}]")
            continue

        # 2. 构造 Jina Reader URL
        jina_url = f"https://r.jina.ai/{url}"
        
        try:
            # 加上合理的超时，避免节点卡死
            response = requests.get(jina_url, timeout=15)
            
            if response.status_code == 200:
                # 截取前 3000 字符，防止单个网页过长导致下游 LLM 崩溃
                full_text = response.text[:3000] 
                results_text.append(f"### Source {i+1}: {title}\nURL: {url}\n\nCONTENT:\n{full_text}")
            else:
                results_text.append(f"### Source {i+1}: {title}\n[Failed to fetch full content. Using summary]: {item.get('summary')}")
        
        except Exception as e:
            results_text.append(f"### Source {i+1}: {title}\n[Error during fetch]: {str(e)}")
        
        # 稍微停顿一下，防止被 Jina 频率限制
        time.sleep(0.5)

    # 将所有内容合并为一个大字符串交给 LLM
    return "\n\n---\n\n".join(results_text)