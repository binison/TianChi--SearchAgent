from langstudio.core import tool
from dataclasses import dataclass
from typing import List
import requests
from bs4 import BeautifulSoup
import urllib.parse
import concurrent.futures
import re
import json
import ast

@dataclass
class BaikeItem:
    keyword: str
    title: str
    content: str     # 页面全部文本
    url: str
    success: bool
    error_msg: str

@dataclass
class Result:
    items: List[BaikeItem]
    combined_text: str

def fetch_single_baike(keyword: str) -> BaikeItem:
    """
    抓取百度百科页面的全部可见文本（剔除导航栏、脚本等噪音）
    """
    session = requests.Session()
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Referer': 'https://baike.baidu.com/'
    }
    session.headers.update(headers)
    
    quoted_kw = urllib.parse.quote(keyword)
    
    urls_to_try = [
        f"https://baike.baidu.com/item/{quoted_kw}",
        f"https://baike.baidu.com/search/word?word={quoted_kw}"
    ]

    for url in urls_to_try:
        try:
            response = session.get(url, timeout=10, allow_redirects=True)
            response.encoding = 'utf-8'

            if response.status_code != 200:
                continue

            if "百度百科尚未收录词条" in response.text or "百度百科：搜索结果" in response.text:
                continue
            
            if "wappass.baidu.com" in response.url:
                return BaikeItem(keyword, "", "", url, False, "触发百度验证码")

            soup = BeautifulSoup(response.text, 'html.parser')

            # --- 1. 清理明显的噪音 ---
            # 移除 脚本, 样式, 导航栏, 页脚, 引用角标, 推荐阅读, 侧边栏广告等
            noise_selectors = [
                'script', 'style', 'sup', 
                '.navbar', '.bottom-bar', '.footer', '.side-content', 
                '.tashuo-bottom', '#tashuo_bottom',  # 他说栏目
                '.d-layout', '.new-side-content', # 侧边栏
                '.reference-list', # 参考资料 (如果不想要的话)
                '.share-group'
            ]
            for selector in noise_selectors:
                for tag in soup.select(selector):
                    tag.decompose()
            
            # 2. 锁定特定内容区域，防止抓取到无关的全站导航
            # 百度百科的主体通常在 div.main-content 或 div.content-wrapper
            content_node = (
                soup.find('div', class_='main-content') or 
                soup.find('div', class_='content-wrapper') or
                soup.find('body') # 兜底
            )
            
            title_node = soup.find('h1')
            title_text = title_node.get_text().strip() if title_node else keyword
            
            # 3. 提取全部文本
            # get_text 使用换行符分隔块级元素，strip=True 去除首尾空格
            full_text = content_node.get_text(separator='\n', strip=True)
            
            # 4. 简单的文本清洗：合并过多的空行
            full_text = re.sub(r'\n{3,}', '\n\n', full_text)

            return BaikeItem(
                keyword=keyword, 
                title=title_text, 
                content=full_text,
                url=response.url, 
                success=True, 
                error_msg=""
            )

        except Exception as e:
            continue

    return BaikeItem(keyword, "", "", "", False, "未收录或抓取失败")

@tool
def invoke(input_str: str) -> Result:
    """
    抓取百度百科页面全部文字内容。
    支持输入 JSON 格式或逗号分隔的关键词列表。
    """
    if not input_str:
        return Result(items=[], combined_text="输入内容为空")

    raw_keywords = []

    # 策略 1: 尝试 JSON 解析
    try:
        data = json.loads(input_str)
        if isinstance(data, list):
            raw_keywords = data
        elif isinstance(data, dict):
            # 常见 key 推测
            for key in ["entities", "keywords", "items", "queries", "list"]:
                if key in data and isinstance(data[key], list):
                    raw_keywords = data[key]
                    break
            # 如果没找到常见key，尝试找 values 里为 list 的
            if not raw_keywords:
                for val in data.values():
                    if isinstance(val, list):
                        raw_keywords = val
                        break
    except Exception:
        pass

    # 策略 2: 尝试 Python AST 解析
    if not raw_keywords:
        try:
            data = ast.literal_eval(input_str)
            if isinstance(data, list):
                raw_keywords = data
            elif isinstance(data, dict):
                for key in ["entities", "keywords", "items", "queries", "list"]:
                    if key in data and isinstance(data[key], list):
                        raw_keywords = data[key]
                        break
        except Exception:
            pass

    # 策略 3: 正则分割 fallback
    if not raw_keywords:
        if '{' in input_str and '}' in input_str:
            parts = re.split(r'[,，、\n]+', input_str)
            for p in parts:
                clean = re.sub(r'[\[\]\{\}"\']', '', p).strip()
                if clean and ':' not in clean and 'entities' not in clean: 
                    raw_keywords.append(clean)
        else:
            raw_keywords = re.split(r'[,，、\n]+', input_str)

    keywords = []
    seen = set()
    for k in raw_keywords:
        s = str(k).strip()
        if s and s not in seen:
            keywords.append(s)
            seen.add(s)

    print(f"\n收到原始输入: {input_str}")
    print(f"最终解析出 {len(keywords)} 个关键字: {keywords}")
    
    items = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        items = list(executor.map(fetch_single_baike, keywords))

    text_parts = []
    for item in items:
        if item.success:
            block = (
                f"=== 词条：{item.title} ===\n"
                f"URL: {item.url}\n\n"
                f"{item.content}"
            )
        else:
            block = f"=== 词条：{item.keyword} ===\n[抓取失败: {item.error_msg}]"
        text_parts.append(block)
    
    final_text = "\n\n" + "="*50 + "\n\n".join(text_parts)
    
    return Result(items=items, combined_text=final_text)

# ================= 本地测试 =================
if __name__ == "__main__":
    json_input = '{ "entities": ["Python", "埃隆·马斯克"] }'
    
    print("--- Testing Full Text Extraction ---")
    res = invoke(input_str=json_input)
    
    print("\n====== 输出预览 (前2000字) ======")
    print(res.combined_text[:2000])