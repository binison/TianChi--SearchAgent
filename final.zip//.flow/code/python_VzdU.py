from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class CluesResult:
    merged_clues: str  # 修改为 str

@tool
def invoke(new_extracted_clues: str, existing_clues: str) -> CluesResult:
    """
    State Update Node (String Version): Merges new findings string with historical clues string.
    
    Args:
        new_extracted_clues: A newline-separated string of new facts. 
                             Example: "- Fact A\n- Fact B"
        existing_clues: A newline-separated string of old clues.
        
    Returns:
        A deduplicated, newline-separated string containing all clues.
    """
    
    # 1. 安全检查 & 预处理
    if not existing_clues:
        existing_clues = ""
    if not new_extracted_clues:
        new_extracted_clues = ""
        
    # 2. 将字符串拆分为列表以便处理
    # 假设线索是用换行符分隔的，可能带有 "- " 前缀
    list_existing = [line.strip() for line in existing_clues.split('\n') if line.strip()]
    list_new = [line.strip() for line in new_extracted_clues.split('\n') if line.strip()]

    # 3. 合并与去重 (保持顺序)
    all_clues_list = list_existing + list_new
    unique_clues = []
    seen = set()
    
    for clue in all_clues_list:
        # 简单的规范化：去掉开头的 "- " 或 "* " 以便去重比较
        normalized_clue = clue.lstrip('-* ').strip()
        
        if normalized_clue and normalized_clue not in seen:
            unique_clues.append(clue) # 这里保留原始格式（带不带前缀看上面拆分时的选择）
            seen.add(normalized_clue)

    # 4. 重新组合成字符串返回
    # 使用换行符拼接。如果你希望每行前面都有个 "- "，可以这里统一加。
    # 比如：merged_string = "\n".join([f"- {c}" if not c.startswith("-") else c for c in unique_clues])
    merged_string = "\n".join(unique_clues)

    return CluesResult(merged_clues=merged_string)