from langstudio.core import tool
from dataclasses import dataclass
import json
import datetime

@dataclass
class HistoryResult:
    updated_history: str

@tool
def merge_decision_to_history(
    current_history: str, 
    decision_json: str
) -> HistoryResult:
    """
    Parses the decision JSON and appends the reasoning and action plan 
    to the global message history string.
    """
    
    # 1. 初始化历史 (防止 None)
    base_history = current_history if current_history else "System: Investigation Started."
    
    # 2. 解析 JSON 输入
    try:
        # 尝试清洗可能存在的 markdown 标记 (```json ... ```)
        cleaned_json = decision_json.strip()
        if cleaned_json.startswith("```"):
            lines = cleaned_json.split("\n")
            # 去掉第一行(```json)和最后一行(```)
            if len(lines) >= 2:
                cleaned_json = "\n".join(lines[1:-1])
        
        data = json.loads(cleaned_json)
        
        thought = data.get("thought_process", "No reasoning provided.")
        decision = data.get("decision", "unknown")
        
        # 3. 构造日志条目
        # 使用清晰的分隔符，方便 LLM 阅读
        log_entry = f"\n\n--- [Step Reasoning & Plan] ---\n"
        log_entry += f"Date: {datetime.datetime.now().strftime('%H:%M:%S')}\n"
        log_entry += f"Thought Process: {thought}\n"
        log_entry += f"Decision: {decision.upper()}\n"
        
        if decision == "search":
            query = data.get("search_query", "N/A")
            log_entry += f"Action Plan: Will search for '{query}'\n"
        elif decision == "finish":
            answer = data.get("answer_payload", "N/A")
            log_entry += f"Action Plan: Ready to submit final answer: {answer}\n"
            
        log_entry += "-------------------------------"

        # 4. 合并
        return HistoryResult(updated_history=base_history + log_entry)

    except json.JSONDecodeError:
        # 兜底：如果 JSON 解析失败，直接追加原始文本，避免崩溃
        fallback_entry = f"\n\n--- [Step Raw Output] ---\n{decision_json}\n-----------------------"
        return HistoryResult(updated_history=base_history + fallback_entry)
        
    except Exception as e:
        # 兜底：其他错误
        error_entry = f"\n\n[System Error]: Failed to log decision. {str(e)}"
        return HistoryResult(updated_history=base_history + error_entry)