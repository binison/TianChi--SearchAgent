from langstudio.core import tool
from dataclasses import dataclass
import json

@dataclass
class Result:
    keyword1: str
    keyword2: str
    keyword3: str

@tool
def invoke(input_json: str) -> Result:
    """
    将输入的 JSON 字符串解析并拆分成三个关键词。
    输入格式: "[\"关键词1\", \"关键词2\", \"关键词3\"]"
    """
    # 解析 JSON 字符串
    keywords = json.loads(input_json)
    
    # 拆分成三个关键词
    keyword1 = keywords[0] if len(keywords) > 0 else ""
    keyword2 = keywords[1] if len(keywords) > 1 else ""
    keyword3 = keywords[2] if len(keywords) > 2 else ""
    
    return Result(
        keyword1=keyword1,
        keyword2=keyword2,
        keyword3=keyword3
    )