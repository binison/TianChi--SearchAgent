import re
from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class FilterResult:
    content: str  # 过滤掉 think 后的纯净内容

@tool
def invoke(raw_output: str) -> FilterResult:
    """
    过滤 LLM 输出中的 <think>...</think> 标签内容，只保留正式回复部分。
    """
    # 1. 使用正则表达式匹配 <think> 标签及其内部所有内容（包括换行符）
    # re.DOTALL 确保 . 可以匹配换行符
    # re.sub 将匹配到的部分替换为空字符串
    clean_text = re.sub(r'<think>[\s\S]*?</think>', '', raw_output)
    
    # 2. 去除首尾多余的空白字符，保持输出整洁
    final_content = clean_text.strip()
    
    # 3. 如果过滤后内容为空（防止模型只输出了 think），返回原始输出或警告
    if not final_content:
        final_content = raw_output
        
    return FilterResult(content=final_content)