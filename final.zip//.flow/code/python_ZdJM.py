import json
from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class Result:
    merged_result: str

@tool
def invoke(new_entities_str: str, history_entities_str: str) -> Result:
    """
    简单合并两个 JSON 列表字符串并去重。
    """
    # 1. 解析输入的 JSON 字符串，解析失败则默认为空列表
    try:
        new_data = json.loads(new_entities_str) if new_entities_str else []
        # 如果是字典（例如 {"top_3": ["A", "B"]}），取第一个值作为列表
        if isinstance(new_data, dict):
            new_list = next(iter(new_data.values()), [])
        elif isinstance(new_data, list):
            new_list = new_data
        else:
            new_list = []
    except:
        new_list = []

    try:
        history_list = json.loads(history_entities_str) if history_entities_str else []
        if not isinstance(history_list, list):
            history_list = []
    except:
        history_list = []

    # 2. 合并 + 简单去重 (利用 set)
    # 注意：set 会打乱顺序，如果不介意顺序这是最高效的方法
    merged_set = set(history_list + new_list)
    
    # 3. 转回 List 再转 JSON 字符串
    return Result(merged_result=json.dumps(list(merged_set), ensure_ascii=False))