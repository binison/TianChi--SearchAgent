import json
import re
import requests
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class Result:
    data_json: str
    status: str

def _search_arxiv_single_keyword(keyword):
    """
    单个关键词的 arXiv 搜索逻辑，限制作者数量。
    """
    api_base = "http://export.arxiv.org/api/query"
    params = {
        "search_query": f"all:{keyword}",
        "start": 0,
        "max_results": 3,
        "sortBy": "relevance",
        "sortOrder": "descending"
    }

    try:
        response = requests.get(api_base, params=params, timeout=15)
        response.raise_for_status()
        
        # 解析 Atom XML
        root = ET.fromstring(response.content)
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        
        entries = root.findall('atom:entry', ns)
        if not entries:
            return []

        results = []
        for entry in entries:
            # 清理标题
            title = entry.find('atom:title', ns).text
            title = re.sub(r'\s+', ' ', title).strip()
            
            # 提取 arXiv ID
            arxiv_id = entry.find('atom:id', ns).text.split('/')[-1]
            
            # 提取摘要
            summary = entry.find('atom:summary', ns).text
            summary = re.sub(r'\s+', ' ', summary).strip()
            
            # --- 作者提取优化逻辑 (核心修改) ---
            all_authors = [author.find('atom:name', ns).text for author in entry.findall('atom:author', ns)]
            
            # 限制最多 5 个作者，超出添加 et al.
            display_authors = all_authors[:5]
            authors_str = ", ".join(display_authors)
            if len(all_authors) > 5:
                authors_str += ", et al."
            # -----------------------------------
            
            results.append({
                "keyword": keyword,
                "id": arxiv_id,
                "title": title,
                "url": f"https://arxiv.org/abs/{arxiv_id}",
                "summary": summary,
                "authors": authors_str,
                "method": "arXiv API"
            })
        return results

    except Exception as e:
        return [{"keyword": keyword, "error": f"arXiv Error: {str(e)}"}]

@tool
def invoke_arxiv(llm_output: str) -> Result:
    """
    解析 JSON 并执行并发 arXiv 学术搜索，限制作者显示。
    """
    # 1. 解析 LLM 输出
    try:
        match = re.search(r'\{.*\}', llm_output, re.DOTALL)
        if not match:
            return Result(data_json="[]", status="No JSON found")
        parsed_output = json.loads(match.group())
    except Exception as e:
        return Result(data_json="[]", status=f"JSON Error: {str(e)}")

    if not parsed_output.get("need_academic", False):
        return Result(data_json="[]", status="Decision: No arXiv search needed")

    queries = parsed_output.get("queries", [])
    if not queries:
        return Result(data_json="[]", status="No queries provided")

    # 2. 并发搜索 (max_workers=3 符合 arXiv API 的礼貌调用建议)
    all_results = []
    with ThreadPoolExecutor(max_workers=3) as executor:
        batch_results = list(executor.map(_search_arxiv_single_keyword, queries))
        for sublist in batch_results:
            all_results.extend(sublist)

    return Result(
        data_json=json.dumps(all_results, ensure_ascii=False),
        status=f"ArXiv search completed: {len(all_results)} papers found"
    )