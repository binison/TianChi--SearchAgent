from langstudio.core import tool
from dataclasses import dataclass
from typing import Union, List

@dataclass
class CluesResult:
    merged_clues: str 

@tool
def invoke(new_extracted_clues: Union[str, List[str]], existing_clues: Union[str, List[str]]) -> CluesResult:
    """
    State Update Node: 兼容处理字符串或列表形式的线索输入。
    """
    
    # --- 1. 辅助函数：将输入统一转换为列表 ---
    def to_list(input_data):
        if not input_data:
            return []
        if isinstance(input_data, list):
            # 如果已经是列表，直接处理每个元素
            return [str(item).strip() for item in input_data if str(item).strip()]
        if isinstance(input_data, str):
            # 如果是字符串，按换行符拆分
            return [line.strip() for line in input_data.split('\n') if line.strip()]
        return [str(input_data)] # 兜底处理

    # --- 2. 转换输入 ---
    list_existing = to_list(existing_clues)
    list_new = to_list(new_extracted_clues)

    # --- 3. 合并与去重 (保持顺序) ---
    all_clues_list = list_existing + list_new
    unique_clues = []
    seen = set()
    
    for clue in all_clues_list:
        # 规范化：移除前缀以准确判断重复
        normalized_clue = clue.lstrip('-* •').strip()
        
        if normalized_clue and normalized_clue not in seen:
            # 统一输出格式：确保每行都有 "- " 前缀（可选，根据你的需求决定）
            formatted_clue = f"- {normalized_clue}"
            unique_clues.append(formatted_clue)
            seen.add(normalized_clue)

    # --- 4. 重新组合成字符串返回 ---
    merged_string = "\n".join(unique_clues)

    return CluesResult(merged_clues=merged_string)