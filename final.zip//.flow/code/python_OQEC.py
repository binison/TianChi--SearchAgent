from langstudio.core import tool
from dataclasses import dataclass
import requests
import json

@dataclass
class Result:
    success: bool
    status_code: int
    response_data: dict
    error_message: str = ""

@tool
def bocha_web_search(query: str, summary: bool = True, freshness: str = "noLimit", count: int = 10) -> Result:
    """
    调用 Bocha 搜索引擎 API 进行网页搜索
    
    Args:
        query: 搜索关键词
        summary: 是否返回摘要
        freshness: 时间范围限制 (noLimit, oneDay, oneWeek, oneMonth, oneYear)
        count: 返回结果数量 (1-50)
    
    Returns:
        Result: 包含搜索结果的 dataclass
    """
    
    url = "https://api.bocha.cn/v1/web-search"
    
    # 请求头
    headers = {
        "Authorization": "Bearer sk-30632e1c4bd644e8bb34e7a2c51ef358",  # ⚠️ 请替换为你的实际密钥
        "Content-Type": "application/json"
    }
    
    # 请求体 - 注意布尔值和数字不要加引号
    payload = {
        "query": query,
        "summary": summary,      # Python 中的 True/False 会自动转换为 JSON 的 true/false
        "freshness": freshness,
        "count": count
    }
    
    try:
        # 发送 POST 请求 - 使用 json 参数自动序列化
        response = requests.post(
            url=url,
            headers=headers,
            json=payload,  # ✅ 关键：使用 json 参数，不要用 data
            timeout=30
        )
        
        # 尝试解析响应 JSON
        try:
            response_data = response.json()
        except:
            response_data = {"raw_text": response.text}
        
        # 返回结果
        return Result(
            success=response.status_code == 200,
            status_code=response.status_code,
            response_data=response_data
        )
        
    except requests.exceptions.RequestException as e:
        # 网络请求异常处理
        return Result(
            success=False,
            status_code=0,
            response_data={},
            error_message=f"请求失败: {str(e)}"
        )
    except Exception as e:
        # 其他异常处理
        return Result(
            success=False,
            status_code=0,
            response_data={},
            error_message=f"未知错误: {str(e)}"
        )