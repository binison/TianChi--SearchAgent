from langstudio.core import tool
from dataclasses import dataclass
import json
import re
# 移除 Optional 引用，因为这里的目标是全量 str

@dataclass
class ConsensusExtraction:
    status: str            # 分支控制: "FINALIZE" 或 "SEARCH"
    analysis: str          # 对应 JSON 中的 analysis
    confirmed_facts: str   # 对应 JSON 中的 confirmed_facts
    common_answer: str     # 【修改】严格限制为 string 类型，若无答案则对应空字符串 ""
    search_query: str      # 对应 JSON 中的 search_suggestion
    needs_search: bool     # 对应 JSON 中的 needs_search
    raw_json: str = ""     # 返回提取到的原始 JSON 字符串

@tool
def extract_consensus_result(raw_llm_output: str) -> ConsensusExtraction:
    """
    严格按照业务 JSON 格式解析共识审计结果。
    common_answer 已强制转换为 string 类型。
    """
    # 默认兜底状态 (修改: common_answer 默认为空字符串)
    default_fallback = ConsensusExtraction(
        status="SEARCH",
        analysis="Parser Error: JSON 提取失败或格式严重错误",
        confirmed_facts="无法确认事实",
        common_answer="",  # 【修改】默认为空串
        search_query="执行原始问题搜索",
        needs_search=True,
        raw_json=""
    )

    try:
        if not raw_llm_output:
            return default_fallback

        target_json_str = ""
        
        # --- 策略1: 优先提取 Markdown 代码块 (```json ... ```) ---
        code_block_pattern = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.DOTALL | re.IGNORECASE)
        match = code_block_pattern.search(raw_llm_output)
        
        if match:
            target_json_str = match.group(1)
        else:
            # --- 策略2: 如果没有代码块，寻找最外层的花括号 ---
            match = re.search(r"\{.*\}", raw_llm_output, re.DOTALL)
            if match:
                target_json_str = match.group(0)
            else:
                print(f"[Extract Tool] 未找到 JSON 结构。原始输出前50字符: {raw_llm_output[:50]}")
                return default_fallback

        # --- 清理步骤: 移除可能存在的非法尾部引号 ---
        target_json_str = target_json_str.strip()
        if target_json_str.endswith('"}'): 
            target_json_str = target_json_str[:-1]

        # 【保存原始提取的 JSON 字符串（清理后）】
        extracted_raw_json = target_json_str

        # 尝试解析
        try:
            data = json.loads(target_json_str)
        except json.JSONDecodeError as e:
            print(f"[Extract Tool] JSON 解析错误: {e}")
            # 即使解析失败也返回提取到的原始 JSON
            return ConsensusExtraction(
                status="SEARCH",
                analysis=f"JSON Parse Error: {str(e)}",
                confirmed_facts="无法确认事实",
                common_answer="", # 【修改】默认为空串
                search_query="执行原始问题搜索",
                needs_search=True,
                raw_json=extracted_raw_json
            )

        # --- 字段提取与类型转换 ---
        raw_status = data.get("consensus_status", "DIVERGENT")
        needs_search_flag = data.get("needs_search", True)
        
        # 【修改】特殊处理 common_answer，强制转为 string
        c_answer = data.get("common_answer")
        # 如果是 None, "null", "None" 或原本就是空，则转为 ""，否则转为 str()
        if c_answer in [None, "null", "None"]:
            c_answer = ""
        else:
            c_answer = str(c_answer)

        # 路由逻辑判定
        if (not needs_search_flag) and (raw_status == "CONSENSUS"):
            execute_status = "FINALIZE"
        else:
            execute_status = "SEARCH"

        return ConsensusExtraction(
            status=execute_status,
            analysis=data.get("analysis", ""),
            confirmed_facts=str(data.get("confirmed_facts", "")),
            common_answer=c_answer, # 这里现在是严格的 string
            search_query=data.get("search_suggestion", "") or data.get("search_query", ""),
            needs_search=bool(needs_search_flag),
            raw_json=extracted_raw_json
        )

    except Exception as e:
        print(f"[Extract Tool] 未知异常: {str(e)}")
        return default_fallback