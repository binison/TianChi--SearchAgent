import re
from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class Result:
    cleaned_text: str

@tool
def invoke(input_text: str) -> Result:
    """
    去除输入文本中括号及其内部的内容。
    
    """
    
    # 使用正则表达式去除括号及内容
    # \s*   匹配括号前可能存在的空格
    # \(    匹配左括号
    # [^)]* 匹配非右括号的任意字符
    # \)    匹配右括号
    result = re.sub(r'\s*\([^)]*\)', '', input_text)
    
    # 去除首尾可能剩余的空白字符
    result = result.strip()

    return Result(cleaned_text=result)