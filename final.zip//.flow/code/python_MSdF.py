from langstudio.core import tool
from dataclasses import dataclass
import json

@dataclass
class Result:
    merged_history: str  # 合并后的搜索历史（JSON字符串列表）

@tool
def invoke(existing_history: str, current_queries: str) -> Result:
    """
    合并历史搜索记录与本次搜索关键词。
    
    Args:
        existing_history: 已有搜索历史，JSON字符串列表格式，如 '["query1", "query2"]' 或空字符串
        current_queries: 本次生成的搜索关键词，JSON字符串列表格式，如 '["new_query1", "new_query2"]'
    
    Returns:
        Result: 包含合并后搜索历史的Result对象
    """
    
    # 解析历史搜索记录
    history_list = []
    if existing_history and existing_history.strip():
        try:
            history_list = json.loads(existing_history)
            if not isinstance(history_list, list):
                history_list = []
        except json.JSONDecodeError:
            # 如果不是JSON格式，尝试按行分割（兼容旧格式）
            history_list = [line.strip() for line in existing_history.split('\n') if line.strip()]
    
    # 解析本次搜索关键词
    current_list = []
    if current_queries and current_queries.strip():
        try:
            current_list = json.loads(current_queries)
            if not isinstance(current_list, list):
                current_list = [str(current_list)]
        except json.JSONDecodeError:
            # 如果不是JSON格式，作为单个字符串处理
            current_list = [current_queries.strip()]
    
    # 合并并去重（保持顺序）
    merged_set = set()
    merged_list = []
    
    for query in history_list + current_list:
        query_normalized = query.strip().lower()
        if query_normalized and query_normalized not in merged_set:
            merged_set.add(query_normalized)
            merged_list.append(query.strip())
    
    # 返回JSON格式的字符串
    return Result(merged_history=json.dumps(merged_list, ensure_ascii=False))