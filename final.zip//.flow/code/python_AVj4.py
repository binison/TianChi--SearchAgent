from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class Result:
    output1: str
    output2: int

@tool
def invoke(input1: str, input2: int) -> Result:
    """
    This is a test tool.
    """


    return Result(output1="Hello: " + input1, output2=input2 + 10)
