import json
import re
import requests
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from langstudio.core import tool
from dataclasses import dataclass

@dataclass
class Result:
    data_json: str
    status: str

def _search_pubmed_single_keyword(keyword):
    """
    修改后：支持单个关键词返回多篇文献
    """
    api_base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    tool_name = "geo_agent_tool"
    email = "test@example.com"
    session = requests.Session()

    try:
        # 1. Search 获取多个 ID
        search_params = {
            "db": "pubmed",
            "term": keyword,
            "retmode": "json",
            "retmax": "3",  # 保持 3 篇
            "sort": "relevance",
            "tool": tool_name,
            "email": email
        }
        r_search = session.get(f"{api_base}/esearch.fcgi", params=search_params, timeout=10)
        id_list = r_search.json().get("esearchresult", {}).get("idlist", [])

        if not id_list:
            return [] # 返回空列表，方便后续 extend

        # 2. Fetch 一次性抓取 ID 列表中的所有文献
        ids_str = ",".join(id_list)
        fetch_params = {
            "db": "pubmed",
            "id": ids_str,
            "retmode": "xml",
            "tool": tool_name,
            "email": email
        }
        r_fetch = session.get(f"{api_base}/efetch.fcgi", params=fetch_params, timeout=10)
        
        if not r_fetch.content:
             return []
             
        root = ET.fromstring(r_fetch.content)

        # 3. Parse 循环解析 XML 中的每一个 PubmedArticle
        results = []
        # 注意：PubMed 返回的多个文章包裹在 PubmedArticle 标签中
        for article_entry in root.findall(".//PubmedArticle"):
            # 获取当前文章的 PMID
            current_pmid = article_entry.find(".//PMID").text
            article = article_entry.find(".//Article")
            
            # Title
            title_node = article.find("ArticleTitle")
            title_text = title_node.text if (title_node is not None and title_node.text) else "No Title"

            # Authors
            authors = []
            author_list_node = article.find("AuthorList")
            if author_list_node is not None:
                for author in author_list_node.findall("Author"):
                    l_name = getattr(author.find("LastName"), 'text', "")
                    f_name = getattr(author.find("ForeName"), 'text', "")
                    if l_name or f_name:
                        authors.append(f"{l_name} {f_name}".strip())
            authors_text = ", ".join(authors) if authors else "Unknown Authors"

            # Summary
            abstract_node = article.find("Abstract")
            summary_text = "No Abstract Available."
            if abstract_node is not None:
                texts = abstract_node.findall("AbstractText")
                summary_chunks = [f"[{t.get('Label')}] {t.text}" if t.get('Label') else (t.text or "") for t in texts]
                summary_text = "\n".join(summary_chunks) if summary_chunks else "摘要为空"

            results.append({
                "keyword": keyword,
                "id": current_pmid,
                "title": title_text,
                "url": f"https://pubmed.ncbi.nlm.nih.gov/{current_pmid}/",
                "summary": summary_text,
                "authors": authors_text,
                "method": "PubMed API"
            })
            
        return results

    except Exception as e:
        return [{"keyword": keyword, "error": str(e)}]

@tool
def invoke(llm_output: str) -> Result:
    # 1. JSON 提取逻辑（保持不变）
    try:
        match = re.search(r'\{.*\}', llm_output, re.DOTALL)
        if not match:
            return Result(data_json="[]", status="No JSON object found")
        parsed_output = json.loads(match.group())
    except Exception as e:
        return Result(data_json="[]", status=f"JSON Decode Error: {str(e)}")

    if not parsed_output.get("need_academic", False):
        return Result(data_json="[]", status="Decision: No academic search needed")

    queries = parsed_output.get("queries", [])
    if not queries:
        return Result(data_json="[]", status="No queries")

    # 2. 并发执行并展平结果
    all_results = []
    with ThreadPoolExecutor(max_workers=3) as executor:
        # map 会返回一个迭代器，其中每个元素是该关键词对应的列表
        batch_results = list(executor.map(_search_pubmed_single_keyword, queries))
        
        # 展平（Flatten）列表：因为每个关键词现在返回一个 list
        for sublist in batch_results:
            all_results.extend(sublist)

    return Result(
        data_json=json.dumps(all_results, ensure_ascii=False),
        status=f"Total {len(all_results)} articles found for {len(queries)} queries"
    )