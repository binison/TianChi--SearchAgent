import json
import re
from langstudio.core import tool
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class ParsedOutput:
    # 实体提取字段
    top_3_entities: List[str]
    # 学术搜索字段
    need_academic: bool
    queries: List[str]
    reason: str
    # 状态标记
    parse_success: bool

@tool
def llm_output_parser(raw_text: str) -> ParsedOutput:
    """
    专门用于解析并清洗 LLM 输出的 JSON 字符串。
    支持处理 Markdown 代码块及冗余文字。
    """
    # 默认空值
    result_dict = {
        "top_3_entities": [],
        "need_academic": False,
        "queries": [],
        "reason": "No reason provided"
    }
    success = False

    try:
        # 1. 强力提取 JSON 核心部分 (匹配第一个 { 到最后一个 })
        # re.DOTALL 确保可以匹配换行符
        json_match = re.search(r'\{.*\}', raw_text, re.DOTALL)
        
        if json_match:
            json_str = json_match.group()
            # 2. 解析 JSON
            parsed = json.loads(json_str)
            
            # 3. 字段合并与清洗 (保持对两个不同 Prompt 节点的兼容)
            result_dict["top_3_entities"] = parsed.get("top_3_entities", [])
            result_dict["need_academic"] = parsed.get("need_academic", False)
            result_dict["queries"] = parsed.get("queries", [])
            result_dict["reason"] = parsed.get("reason", "Parsed successfully")
            success = True
            
    except Exception as e:
        result_dict["reason"] = f"Parse Error: {str(e)}"
        success = False

    return ParsedOutput(
        top_3_entities=result_dict["top_3_entities"],
        need_academic=result_dict["need_academic"],
        queries=result_dict["queries"],
        reason=result_dict["reason"],
        parse_success=success
    )